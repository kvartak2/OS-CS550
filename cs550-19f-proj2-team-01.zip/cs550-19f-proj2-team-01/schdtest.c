#include "types.h"
#include "user.h"
//#include "proc.h"

#define P_LOOP_CNT 0x01000000
#define C_LOOP_CNT 0x03000000


void do_parent(void)
{
    volatile int cnt = 0;
    volatile int tmp = 0;

    while(cnt < P_LOOP_CNT)
    {
        tmp += cnt;
        cnt ++;
    }
}


void do_child(void)
{
    volatile int cnt = 0;
    volatile int tmp = 0;

    while(cnt < C_LOOP_CNT)
    {
        tmp += cnt;
        cnt ++;
    }

    exit();
}


int
main(int argc, char *argv[])
{

  enable_sched_trace(1);

    /* ---------------- start: add your test code ------------------- */

    int set_sched_enabled;



    set_sched_enabled = atoi(argv[1]);
    int set_switch = atoi(argv[2]);
    //printf(1,"%d\n", set_switch);
    set_sched(set_sched_enabled);

    switch(set_switch)
    {
      case 2:
              {
                int pid = fork();
                if (pid < 0)
                {
                  printf(1, "fork() failed!\n");
                  exit();
                }
                else if (pid == 0) // child
                {
                  int x = -1;

                  set_priority(getpid(), x);
                  do_child();
                }
                else // parent
                {
                  int pid1 = fork();
                  if (pid1 < 0)
                  {
                    printf(1, "fork() failed!\n");
                    exit();
                  }
                  else if (pid1 == 0) // child
                  {
                    int y = 0;
                    set_priority(getpid(), y);
                    do_child();
                  }

                  int z = 1;
                  set_priority(getpid(),z);
                  do_parent();


                  wait();
                }
                if (wait() < 0)
                {
                  printf(1, "wait() failed!\n");
                }
              }//case-2 end
              break;
      case 3:
              {
                int pid = fork();
                if (pid < 0)
                {
                  printf(1, "fork() failed!\n");
                  exit();
                }
                else if (pid == 0) // child
                {
                  int x = -1;

                  set_priority(getpid(), x);
                  do_child();
                }
                else
                {
                  int pid3 = fork();
                  if (pid3 < 0)
                  {
                    printf(1, "fork() failed!\n");
                    exit();
                  }
                  else if (pid3 == 0) // child
                  {
                    int x1 = -1;

                    set_priority(getpid(), x1);
                    do_child();
                  }

                  else // parent
                  {
                    int pid1 = fork();
                    if (pid1 < 0)
                    {
                      printf(1, "fork() failed!\n");
                      exit();
                    }
                    else if (pid1 == 0) // child
                    {
                      int y = 0;

                      set_priority(getpid(), y);
                      do_child();
                    }
                    else // parent
                    {
                      int pid2 = fork();
                      if (pid2 < 0)
                      {
                        printf(1, "fork() failed!\n");
                        exit();
                      }
                      else if (pid2 == 0) // child
                      {
                        int y1 = 0;

                        set_priority(getpid(), y1);
                        do_child();
                      }
                      else // parent
                      {
                        int pid4 = fork();
                        if (pid4 < 0)
                        {
                          printf(1, "fork() failed!\n");
                          exit();
                        }
                        else if (pid4 == 0) // child
                        {
                          int z1 = 1;

                          set_priority(getpid(), z1);
                          do_child();
                        }

                        int z = 1;
                        set_priority(getpid(),z);
                        do_parent();
                        if (wait() < 0)
                        {
                          printf(1, "wait() failed!\n");
                        }
                      }
                      wait();
                    }
                  }
                  wait();
                }
                wait();
                if (wait() < 0)
                {
                  printf(1, "wait() failed!\n");
                }
              }//case 3 end
              break;


      default:
      {
        int pid = fork();
        if (pid < 0)
        {
          printf(1, "fork() failed!\n");
          exit();
        }
        else if (pid == 0) // child
        {
          int x = -1;

          set_priority(getpid(), x);
          do_child();
        }
        else // parent
        {
          int pid1 = fork();
          if (pid1 < 0)
          {
            printf(1, "fork() failed!\n");
            exit();
          }
          else if (pid1 == 0) // child
          {
            int y = 0;
            set_priority(getpid(), y);
            do_child();
          }

          int z = 1;
          set_priority(getpid(),z);
          do_parent();


          wait();
        }
        if (wait() < 0)
        {
          printf(1, "wait() failed!\n");
        }
      }
}//switch end
    /* ---------------- end: add your test code ------------------- */

    enable_sched_trace(0);

    exit();
}
