#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(int argc,char* argv[]) {


  int i = 0;
  int pid1, pid2, pid3, status;

  //buffer to read and write into and from pipes
  char buf[256];
  

  int fd1[2], fd2[2], fd3[2], fd4[2], fd5[2], fd6[2];

  //Creating 6 pipes in total
  if(pipe(fd1) == -1) {
    printf("\nError creating pipe 1.\n");
  }

  if(pipe(fd2) == -1) {
    printf("\nError creating pipe 2.\n");
  }

  if(pipe(fd3) == -1) {
    printf("\nError creating pipe 3.\n");
  }

  if(pipe(fd4) == -1) {
    printf("\nError creating pipe 4.\n");
  }
  if(pipe(fd5) == -1) {
    printf("\nError creating pipe 5.\n");
  }

  if(pipe(fd6) == -1) {
    printf("\nError creating pipe 6.\n");
  }

if (argc >= 2) {	
 int in = atoi(argv[1]);
 switch (in) {
  case 2:
    //Create child-1
    pid1=fork();
    //fork() returns a negative on error creating a child-1
    if(pid1<0)  {
      printf("\nerror creating child-1");
    }

    //fork() returns a child process (Child-1)
    else if(pid1==0)  {
      if(close(fd1[0])==-1)
      {
        printf("\nError closing read end of fd1 pipe.");
        exit(0);
      }

      if(close(fd1[1])==-1)
      {
        printf("\nError closing write end of fd1 pipe.");
        exit(0);
      }
      if(close(fd3[0])==-1)
      {
        printf("\nError closing read end of fd3 pipe.");
        exit(0);
      }
      if(close(fd3[1])==-1)
      {
        printf("\nError closing write end of fd3 pipe.");
        exit(0);
      }
      if(close(fd6[1])==-1)
      {
        printf("\nError closing write end of fd6 pipe.");
        exit(0);
      }
      if(close(fd5[0])==-1)
      {
        printf("\nError closing write end of fd5 pipe.");
        exit(0);
      }

      //reading from read end of fd6 pipe between Child-2 and Child-1
      read(fd6[0], buf, sizeof(buf)-1);
      printf("%s (PID=%d) is running.\n", buf, (int) getpid());

      //write to fd5 pipe from its write end betewwn Child-1 and Child-3
      write(fd5[1], "CHILD-3", 12);

    }
    else {
      //fork() returns a parent process

      //create child-2
      pid2=fork();

      //fork() returns a negative on error creating a child-2
      if(pid2<-1)  {
        printf("\nError creating child-2");
      }

      //fork() returns a child process
      else if(pid2==0)  {
          if(close(fd2[1])==-1)
          {
            printf("\nError closing write end of fd2 pipe.");
            exit(0);
          }
          if(close(fd6[0])==-1)
          {
            printf("\nError closing read end of fd6 pipe.");
            exit(0);
          }
          if(close(fd4[0])==-1)
          {
            printf("\nError closing read end of fd4 pipe.");
            exit(0);
          }
          if(close(fd4[1])==-1)
          {
            printf("\nError closing write end of fd4 pipe.");
            exit(0);
          }
          //reading from read end of fd2 pipe betewwn Parent and Child-2
          read(fd2[0], buf, sizeof(buf)-1 );
          printf("%s (PID=%d) is running.\n", buf, (int) getpid());

          //write to fd6 pipe from its write end between Child-2 and Child-1
          write(fd6[1], "CHILD-1", 12);
      }


      else
			{
        //fork() returns a parent process

        //create child-3
				pid3=fork();

        //fork() returns a negative on error creating a child-2
        if(pid3<0)  {
          printf("\nerror creating child-3");
        }

        //fork() returns a child process
				else if(pid3==0) {
            if(close(fd3[0])==-1)
            {
              printf("\nError closing read end of fd3 pipe.");
              exit(0);
            }
            if(close(fd4[0])==-1)
            {
              printf("\nError closing read end of fd4 pipe.");
              exit(0);
            }
            if(close(fd4[1])==-1)
            {
              printf("\nError closing write end of fd4 pipe.");
              exit(0);
            }
            if(close(fd5[1])==-1)
            {
              printf("\nError closing write end of fd5 pipe.");
              exit(0);
            }

            //reading from read end of fd5 pipe between Child-1 and Child-3
            read(fd5[0], buf, sizeof(buf)-1);
            printf("%s (PID=%d) is running.\n", buf, (int) getpid());

            //write to fd3 pipe from its write end between Child-3 and Parent
            write(fd3[1], "Parent", 12);

        }
        else{
          if(close(fd1[0])==-1)
          {
            printf("\nError closing read end of fd1 pipe.");
            exit(0);
          }
          if(close(fd1[1])==-1)
          {
            printf("\nError closing write end of fd1 pipe.");
            exit(0);
          }
          if(close(fd3[1])==-1)
          {
            printf("\nError closing write end of fd3 pipe.");
            exit(0);
          }
          if(close(fd2[0])==-1)
          {
            printf("\nError closing read end of fd2 pipe.");
            exit(0);
          }

          //write to fd2 pipe from its write end between parent and Child-2
          write(fd2[1], "CHILD-2", 12);

          //read from read end of fd3 pipe betewwn Child-3 and Parent
          read(fd3[0], buf, sizeof(buf)-1);

          if (wait(&status) > 0){
            printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid1 );
            printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid2 );
            printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid3 );
          }
          //do not terminate a parent until all its children are terminate
          wait(NULL);
        }
      }
    }
    break;

case 1:
      pid1=fork();

      if(pid1<0) {
        printf("\nerror creating child-1");
      }
      else if(pid1==0)  {
        if(close(fd1[0])==-1)
        {
          printf("\nError closing read end of fd1 pipe.");
          exit(0);
        }
        if(close(fd5[0])==-1)
        {
          printf("\nError closing read end of fd5 pipe.");
          exit(0);
        }
        if(close(fd5[1])==-1)
        {
          printf("\nError closing write end of fd5 pipe.");
          exit(0);
        }
        if(close(fd6[1])==-1)
        {
          printf("\nError closing write end of fd6 pipe.");
          exit(0);
        }

        read(fd6[0],buf,sizeof(buf)-1);
        printf("%s (PID=%d) is running.\n", buf, (int) getpid());

        write(fd1[1],"Parent",12);
      }

      else {

          pid2=fork();
          if (pid2 < 0){
            printf("\nerror creating child-2");
          }
          else if(pid2==0) {
            if(close(fd4[1])==-1)
            {
              printf("\nError closing write end of fd4 pipe.");
              exit(0);
            }
            if(close(fd2[0])==-1)
            {
              printf("\nError closing read end of fd2 pipe.");
              exit(0);
            }
            if(close(fd2[1])==-1)
            {
              printf("\nError closing write end of fd2 pipe.");
              exit(0);
            }
            if(close(fd6[0])==-1)
            {
              printf("\nError closing read end of fd6 pipe.");
              exit(0);
            }
            read(fd4[0],buf,sizeof(buf)-1);
            printf("%s (PID=%d) is running.\n", buf, (int) getpid());

            write(fd6[1],"CHILD-1",12);
          }
          else {
            pid3=fork();
            if(pid3 < 0){
              printf("error creating child-3\n");
            }
            else if(pid3==0)
            {
              if(close(fd5[0])==-1)
              {
                printf("\nError closing read end of fd5 pipe.");
                exit(0);
              }
              if(close(fd5[1])==-1)
              {
                printf("\nError closing write end of fd5 pipe.");
                exit(0);
              }

              read(fd3[0],buf, sizeof(buf)-1);
              printf("%s (PID=%d) is running.\n", buf, (int) getpid());
              if(close(fd3[0])==-1)
              {
                printf("\nError closing read end of fd3 pipe.");
                exit(0);
              }

              write(fd4[1],"CHILD-2",12);
              if(close(fd4[0])==-1)
              {
                printf("\nError closing read end of fd4 pipe.");
                exit(0);
              }
            }

            else  {
            if(close(fd1[1])==-1)
            {
              printf("\nError closing write end of fd1 pipe.");
              exit(0);
            }
            if(close(fd3[0])==-1)
            {
              printf("\nError closing read end of fd3 pipe.");
              exit(0);
            }
            if(close(fd2[0])==-1)
            {
              printf("\nError closing read end of fd6 pipe.");
              exit(0);
            }
            if(close(fd2[1])==-1)
            {
              printf("\nError closing write end of fd2 pipe.");
              exit(0);
            }

            write(fd3[1],"CHILD-3",12);

            read(fd1[0],buf,sizeof(buf)-1);

            if (wait(&status) > 0){
              printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid1 );
              printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid2 );
              printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid3 );

            }
            wait(NULL);
          }
        }
    }
  break;

case 3:
    pid1=fork();

    if(pid1<0) {
      printf("\nerror creating child-1");
    }
    else if(pid1==0)  {
        if(close(fd1[0])==-1)
        {
          printf("\nError closing read end of fd1 pipe.");
          exit(0);
        }
        if(close(fd1[1])==-1)
        {
          printf("\nError closing write end of fd1 pipe.");
          exit(0);
        }
        if(close(fd5[1])==-1)
        {
          printf("\nError closing write end of fd5 pipe.");
          exit(0);
        }
        read(fd5[0], buf, sizeof(buf)-1);
        printf("%s (PID=%d) is running.\n", buf, (int) getpid());

        if(close(fd6[0])==-1)
        {
          printf("\nError closing read end of fd6 pipe.");
          exit(0);
        }
        write(fd6[1],"CHILD-2", 12);
    }

    else{
      pid2 = fork();

      if(pid2<0) {
        printf("\nerror creating child-2");
      }
      else if(pid2 == 0) {
        if(close(fd4[1])==-1)
        {
          printf("\nError closing write end of fd4 pipe.");
          exit(0);
        }
        if(close(fd4[0])==-1)
        {
          printf("\nError closing read end of fd4 pipe.");
          exit(0);
        }
        if(close(fd6[1])==-1)
        {
          printf("\nError closing write end of fd6 pipe.");
          exit(0);
        }
        read(fd6[0], buf, sizeof(buf)-1);
        printf("%s (PID=%d) is running.\n", buf, (int) getpid());

        if(close(fd2[0])==-1)
        {
          printf("\nError closing read end of fd2 pipe.");
          exit(0);
        }
        write(fd2[1], "Parent", 12);

      }

      else {
        pid3 = fork();

        if(pid3 < 0) {
          printf("\nerror creating child-3");
        }
        else if (pid3 == 0) {

            if(close(fd4[1])==-1)
            {
              printf("\nError closing write end of fd4 pipe.");
              exit(0);
            }
            if(close(fd4[0])==-1)
            {
              printf("\nError closing read end of fd4 pipe.");
              exit(0);
            }
            if(close(fd3[1])==-1)
            {
              printf("\nError closing write end of fd6 pipe.");
              exit(0);
            }

            read(fd3[0], buf, sizeof(buf)-1);
            printf("%s (PID=%d) is running.\n", buf, (int) getpid());
            if(close(fd5[0])==-1)
            {
              printf("\nError closing read end of fd5 pipe.");
              exit(0);
            }
            write(fd5[1], "CHILD-1", 12);




        }
        else {
          if(close(fd1[0])==-1)
          {
            printf("\nError closing read end of fd1 pipe.");
            exit(0);
          }
          if(close(fd1[1])==-1)
          {
            printf("\nError closing write end of fd1 pipe.");
            exit(0);
          }
          if(close(fd3[0])==-1)
          {
            printf("\nError closing read end of fd3 pipe.");
            exit(0);
          }

          write(fd3[1], "CHILD-3", 12);

          if(close(fd2[1])==-1)
          {
            printf("\nError closing write end of fd2 pipe.");
            exit(0);
          }
          read(fd2[0], buf, sizeof(buf)-1);

          if (wait(&status) > 0){
            printf("In PARENT (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid1 );
            printf("In PARENT (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid2 );
            printf("In PARENT (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid3 );

          }
          wait(NULL);
        }
      }
    }
    break;
  default:
    break;

}
}
else {
	printf("Enter the input argument\n");
}	
return 0;
}
