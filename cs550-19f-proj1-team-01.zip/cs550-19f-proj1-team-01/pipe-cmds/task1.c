#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 63

int main(int argc,char* argv[]) {
    setbuf(stdout, NULL); // disable I/O buffering - all prints are dumped to terminal immediately

    char *argument1[3];
    char *argument2[3];
    char *argument3[3];
  	int status, pid1, pid2, pid3;
  	char a[3][63];
  	char s1[63], s2[63], s3[63];
  	argv[1] = "cmds";
  	FILE *fp = fopen(argv[1], "r"); /* opening and reading file cmds from argv[1] */
  	char buffe[BUFFER_SIZE];
  	int i = 0;
  	int j;

  	while(fgets(a[i], BUFFER_SIZE - 1, fp) != NULL && (i<=3)) {
  			/* buffer has one line of the file */
  			a[i][strlen(a[i])-1] = '\0';
  			i = i + 1;
  	}
  	/* close the file pointer *fp for file cmds */
  	fclose(fp);



  	/*copying a[0] to s1 to perform string tokenization*/
  	strcpy(s1, a[0]);
  	/*tokenization based on the spaces in the string*/
  	char* token1 = strtok(s1, " ");
  	/*initialize j=0*/
  	j = 0;
  	/*reading tokens and inserting each token value in the argument1 array of strings*/
  	while(token1){
  		argument1[j] = token1;
  		token1 = strtok(NULL, " ");
  		j++;
  	}
  	/*putting NULL value at the end of the array of strings*/
  	argument1[2] = NULL;


  	/*for second argument/argument2*/
  	strcpy(s2, a[1]);
  	char* token2 = strtok(s2, " ");
  	j = 0;
  	while(token2){
  		argument2[j] = token2;
  		token2 = strtok(NULL, " ");
  		j++;
  	}
  	argument2[2] = NULL;


   /*for third argument/argument3*/
  	strcpy(s3, a[2]);
  	char* token3 = strtok(s3, " ");
  	j = 0;
  	while(token3){
  		argument3[j] = token3;
  		token3 = strtok(NULL, " ");
  		j++;
  	}
  	argument3[2] = NULL;


    /* initializing file descriptors for the two pipes and below initiliting pipes*/
  	int fd1[2],fd2[2];

  	if(pipe(fd1) == -1){
  		printf("\nError creating pipe 1.\n");
  	}
  	if(pipe(fd2) == -1){
  		printf("\nError creating pipe 2.\n");
  	}

  	/*forking a process*/
  	pid1 = fork();
  	if(pid1 == 0) {
  		/* Child-1 */
  		printf("In CHILD-1 (PID=%d): executing command cat ...\n",(int) getpid());

  		/*Duplicating write end of the file descriptor of fd1*/
  		dup2(fd1[1],1);
  		close(fd1[0]);		//close read end of Child1 for
  		close(fd1[1]);		//close write end of Child1
  		execvp(argument1[0],argument1);
  		/*this should not be print*/
  		printf("CHILD-1:This should not print.\n");

  	}

  	else {
  		pid2 = fork();
  		if(pid2 == 0) {
        /* Child-2 */
  			printf("In CHILD-2 (PID=%d): executing command head ...\n",(int) getpid());

  			/*duplicating file descriptor fd1 read end and fd2 write end*/
  			dup2(fd1[0],0);
  			dup2(fd2[1],1);

  			close(fd1[0]);
        close(fd1[1]);

  			close(fd2[0]);
        close(fd2[1]);

  			execvp(argument2[0],argument2);
  			printf("In Parent: (PID=%d)\n",(int) getpid());
  		}

  		else {
  			pid3 = fork();
      	if(pid3==0) {
  				/* Child-3 */
  				printf("In CHILD-3 (PID=%d): executing command wc ...\n",(int) getpid());
  				dup2(fd2[0],0);

  				close(fd2[0]);
          close(fd2[1]);

  				execvp(argument3[0],argument3);
  			}
  		}
  	}

    close(fd2[1]);
    close(fd2[0]);

    wait(NULL);                 ///The wait() system call suspends execution of the current process until one of its children terminates.

  	printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid1 );
    printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid2 );
    printf("In Parent (PID=%d): successfully reaped child (PID=%d)\n",(int) getpid(), pid3 );

 return 0;
}
