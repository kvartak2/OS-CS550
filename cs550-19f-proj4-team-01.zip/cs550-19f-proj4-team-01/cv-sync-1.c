/* On-demand 2-thread synchronization */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h> // Compile with "gcc cv-sync-1.c -o cv-sync-1 -lpthread"

pthread_mutex_t lock;
pthread_cond_t cond1 = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond2 = PTHREAD_COND_INITIALIZER;
int x = 0;
int i = 1;
int cn2 = 0;
int cn1 = 0;
int t1_in = 0, t2_in = 0;
long tid;


void usage(char * bin_str) {
    printf("Usage: %s total_runs t1_runs t2_runs\n", bin_str);
}

void *myThread1(void *arg){
  //sleep(1);


  pthread_mutex_lock(&lock);

  //if (t1_in == 0){
  //  while(i<=x){
  //    pthread_cond_wait(&cond1, &lock);
  //    pthread_cond_signal(&cond2);
  //  }
  //}

  for(;i<=x;){
      //printf("t1_n %d\n",t1_in);
    for(int j = 1; j <= t1_in; j++){
      if(i<=x){
        cn1++;
      //  printf("cn1: %d\n", cn1);
        tid = (long)pthread_self();
        printf("i:%d  T1 %ld\n",i,tid);
        i = i+1;
      }
    }
    //else{
    //printf("cn1: %d\n", cn1);
    //printf("t1_in: %d\n", t1_in);

   // if(cn1 % t1_in == 0){
      pthread_cond_wait(&cond1, &lock);
      pthread_cond_signal(&cond2);
   // }
    //  i = i + 1;
    //  if (cn1 % t1_in == 0){

    //  }

    //}
  }


  //printf("T%ld\n",tid);
  //printf("%d",x);

  pthread_cond_signal(&cond2);
  pthread_mutex_unlock(&lock);
  return NULL;
}

void *myThread2(void *arg){
  //sleep(1);


  pthread_mutex_lock(&lock);

  //if (t2_in == 0){
  //  while(i<=x){
  //    pthread_cond_wait(&cond1, &lock);
//      pthread_cond_signal(&cond2);
//    }
//  }

  for(;i<=x;){
    //printf("t2_n %d\n",t2_in);
    for(int k = 1; k <= t2_in; k++){
      if(i<=x){
        cn2++;
      //  printf("cn2: %d\n", cn2);
        tid = (long)pthread_self();
        printf("i:%d  T2 %ld\n",i, tid);
        i = i+1;
      }
    }
    //else{
    //printf("t2_in: %d\n", t2_in);
    //printf("cn2: %d\n", cn2);

    //if(cn2 % t2_in == 0){
      pthread_cond_signal(&cond1);
      pthread_cond_wait(&cond2, &lock);
  //  else{
    //}

      //i = i + 1;
      //if (cn2 % t2_in == 0){
        //pthread_cond_signal(&cond1);
        //pthread_cond_wait(&cond2, &lock);

      //}
  //  }
  }


  //printf("T%ld\n",tid);
  //printf("%d",x);

  pthread_cond_signal(&cond1);
  pthread_mutex_unlock(&lock);
  return NULL;
}

int main(int argc, char * argv[]) {

    if (argc != 4) {
        usage(argv[0]);
        return 0;
    }
    int n;


    if ((x = atoi(argv[1])) < 0){
      usage(argv[0]);
      return 0;
    }

    n = argc;

    t1_in = atoi(argv[2]);
    t2_in = atoi(argv[3]);

    if(t1_in <= 0 && t2_in <= 0){
    	return 0;
    }
    else{
    	pthread_t thread_id[2];

    	pthread_create(&thread_id[0], NULL, myThread1, NULL);
    	pthread_create(&thread_id[1], NULL, myThread2, NULL);

    	pthread_join(thread_id[0], NULL);
    	pthread_join(thread_id[1], NULL);


    	return 0;
	}	
}

